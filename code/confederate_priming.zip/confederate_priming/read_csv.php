<?php
$json = file_get_contents('php://input');
$obj = json_decode($json, true);
$filename = $obj["filename"];
$path = 'trial_lists/'.$filename;

$csv = array_map('str_getcsv', file($path));
array_walk($csv, function(&$a) use ($csv) {
      $a = array_combine($csv[0], $a);
    });
array_shift($csv); # remove column header

#return the read-in csv
print(json_encode($csv));
?>
