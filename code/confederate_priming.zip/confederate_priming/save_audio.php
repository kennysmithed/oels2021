<?php
//strip special characters from filename to prevent any naughtiness
function cleanInput($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = str_replace('/','',$data);
  $data = str_replace('.','',$data);
  return $data;
}
$username = explode("/", dirname(__FILE__))[2];
$server_data = "/home/".$username."/server_data";
$datapath = $server_data.'/audio';
$filename = cleanInput($_REQUEST["filename"]);
copy($_FILES['filedata']['tmp_name'], $datapath . '/' . $filename . ".webm");
?>
